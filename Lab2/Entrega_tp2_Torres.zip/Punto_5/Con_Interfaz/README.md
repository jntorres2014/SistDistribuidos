#
# Como usar... 
#Python 3.7.5

para correr cliente use:
	> python cliente.py
El software pedira cantidad de muestras que desea obtener
Luego pedira cantidad de retardo en los cuales obtener esas muestras.
Al finalizar mostrara una tabla con los valores correspondientes

