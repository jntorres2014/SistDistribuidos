import ntplib
from time import sleep
import threading
import pdb
from datetime import datetime
from tkinter import *
host2= 'europe.pool.ntp.org'
host = 'pool.ntp.org'

def main():
    c = ntplib.NTPClient()
    #r4.set(host2)
    cont=0
    media=0
    menor_rtt=0

    while cont <10:
        hora_mia1= datetime.now()
        response = c.request(host2, version=3)
        hora_mia2= datetime.now()
        hora= datetime.utcfromtimestamp(response.tx_time)
        #promedio de hora que tardo en hacer la peticion
        rtt= (hora_mia2 - hora_mia1)/2 
        print(rtt)
        hora_server_rtt=  hora + rtt
        if  menor_rtt == 0 :
            menor_rtt = hora_server_rtt
        else: 
            if hora_server_rtt < menor_rtt:
                menor_rtt = hora_server_rtt
        #pdb.set_trace()
        cont= cont+1
    #prom_hora = to_integer(menor_rtt)/cont
    #print('prom hora',prom_hora)
    return menor_rtt

def to_integer(dt_time):
    return 10000*dt_time.year + 100*dt_time.month + dt_time.day
