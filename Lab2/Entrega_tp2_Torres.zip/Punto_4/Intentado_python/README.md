#
# Como usar... 
#Python 3.7.5

para iniciar el reloj
	> python reloj.py
mostrara el reloj y los cambios que deberia hacer.
Nota: falta implementacion
